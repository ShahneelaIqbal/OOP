﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3.BL
{
    class Boundary
    {
        public Point TopLeft;
        public Point TopRight;
        public Point BottomLeft;
        public Point BottomRight;

        public Boundary(Point TopLeft, Point TopRight, Point BottomLeft, Point BottomRight)
        {
            this.TopRight = TopRight;
            this.TopLeft = TopLeft;
            this.BottomLeft = BottomLeft;
            this.BottomRight = BottomRight;
        }

        public Boundary()
        {
            TopLeft.setXY(0, 0);
            TopRight.setXY(0, 90);
            BottomLeft.setXY(90, 0);
            BottomRight.setXY(90, 90);
        }

    }
}

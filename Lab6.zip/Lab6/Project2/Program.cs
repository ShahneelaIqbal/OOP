﻿using Project2.DL;
using Project2.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    class Program
    {
        static void Main(string[] args)
        {
            CoffeeShopDL.readData();
            while (true)
            {
                Console.Clear();
                string option = CoffeeShopUI.menu();
                if (option == "1")
                {
                    CoffeeShopDL.addItem();
                }
                else if (option == "2")
                {
                    CoffeeShopDL.cheapItem();
                }
                else if (option == "3")
                {
                    CoffeeShopDL.drinkItem();
                }
                else if (option == "4")
                {
                    CoffeeShopDL.foodItem();
                }
                else if (option == "5")
                {
                    if (!CoffeeShopDL.addOrder())
                    {
                        Console.WriteLine("This Item is Curently Unavailable..");
                    }
                }
                else if (option == "6")
                {
                    CoffeeShopDL.fulOrder();
                }
                else if (option == "7")
                {
                    CoffeeShopDL.drink();
                }
                else if (option == "8")
                {
                    CoffeeShopDL.amount();

                }
                else if (option == "9")
                {
                    break;
                }
                Console.ReadKey();
            }

        }
    }
}

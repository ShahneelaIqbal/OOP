﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project6
{
    class Customer
    {
        public string name;
        public string category;
        public float price;
        public List<product> list;

        public Customer(string name, string category, float price)
        {
            this.name = name;
            this.category = category;
            this.price = price;
        }

        public float calculatetax()
        {
            float tax = 0;
            if (category == "fruit" || category == "Fruit")
            {
                tax = this.price * 0.05F;
                return tax;
            }
            else if (category == "grocery" || category == "Grocery")
            {
                tax = this.price * 0.1F;
                return tax;
            }
            else
            {
                tax = this.price * 0.15F;
                return tax;
            }
            
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pacman
{
    class GameCell
    {
        public GameCell(int x,int y,GameGrid grid)
        {
            this.x = x;
            this.y = y;
            gameGrid = grid;
        }
        public int x;
        public int y;
        public GameObject CurrentGameObject;
        public GameGrid gameGrid;
        public void nextCell(GameDirection direction)
        {
            if (direction==GameDirection.UP)
            {

            }
        }
    }
}

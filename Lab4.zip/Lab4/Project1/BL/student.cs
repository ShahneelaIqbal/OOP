﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.BL
{
    class student
    {
        public string name;
        public int rollNumber;
        public float cGPA;
        public int matricMarks;
        public int fscMarks;
        public int ecatMarks;
        public string homeTown;
        public bool isHostelite;
        
        public student(string name, int rollNumber, float cGPA, int matricMarks, int fscMarks, int ecatMarks, string homeTown, bool isHostelite)
        {
            this.name = name;
            this.rollNumber = rollNumber;
            this.cGPA = cGPA;
            this.matricMarks = matricMarks;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
            this.homeTown = homeTown;
            this.isHostelite = isHostelite;
        }
       
        public float calculateMerit()
        {
            float merit = ((fscMarks * 60.0F)/1100.0F) + ((ecatMarks * 40.0F)/400.0F);
            return merit;
        }
        public bool scholarship(float meritCalculate)
        {
            if(meritCalculate > 80 && isHostelite == true)
            {
                return true;
            }
            return false;
        }
    }
}

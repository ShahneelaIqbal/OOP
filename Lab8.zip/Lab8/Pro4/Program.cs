﻿using Pro4.BL;
using Pro4.BL.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4
{
    class Program
    {
        static void Main(string[] args)
        {
            int option = 0;
            do
            {
                Console.Clear();
                option = UserInterface.mainMenu();
                if (option == 1)
                {
                    Rectangle rect = UserInterface.takeRectangle();
                    UserInterface.addIntoList(rect);
                    Console.ReadKey();
                }
                else if (option == 2)
                {
                    Square sqr = UserInterface.takeSquare();
                    UserInterface.addIntoList(sqr);
                    Console.ReadKey();
                }
                else if (option == 3)
                {
                    Circle cir = UserInterface.takeCircle();
                    UserInterface.addIntoList(cir);
                    Console.ReadKey();
                }
                else
                {
                    UserInterface.showAllShapes();
                    Console.ReadKey();
                }
            }
            while (option != 5);
            Console.ReadKey();
        }
    }
}

﻿
namespace pro1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Fname = new System.Windows.Forms.TextBox();
            this.btnHello = new System.Windows.Forms.Button();
            this.Lname = new System.Windows.Forms.TextBox();
            this.lblName1 = new System.Windows.Forms.Label();
            this.lblName2 = new System.Windows.Forms.Label();
            this.option1 = new System.Windows.Forms.CheckBox();
            this.option2 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Fname
            // 
            this.Fname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fname.Location = new System.Drawing.Point(220, 60);
            this.Fname.Name = "Fname";
            this.Fname.Size = new System.Drawing.Size(285, 37);
            this.Fname.TabIndex = 0;
            this.Fname.TextChanged += new System.EventHandler(this.txtPractice_TextChanged);
            // 
            // btnHello
            // 
            this.btnHello.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnHello.Location = new System.Drawing.Point(612, 326);
            this.btnHello.Name = "btnHello";
            this.btnHello.Size = new System.Drawing.Size(123, 66);
            this.btnHello.TabIndex = 1;
            this.btnHello.Text = "Click It";
            this.btnHello.UseVisualStyleBackColor = false;
            this.btnHello.Click += new System.EventHandler(this.btnHello_Click);
            // 
            // Lname
            // 
            this.Lname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lname.Location = new System.Drawing.Point(220, 119);
            this.Lname.Name = "Lname";
            this.Lname.Size = new System.Drawing.Size(285, 37);
            this.Lname.TabIndex = 2;
            // 
            // lblName1
            // 
            this.lblName1.AutoSize = true;
            this.lblName1.Location = new System.Drawing.Point(74, 60);
            this.lblName1.Name = "lblName1";
            this.lblName1.Size = new System.Drawing.Size(112, 25);
            this.lblName1.TabIndex = 3;
            this.lblName1.Text = "Enter name";
            this.lblName1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblName2
            // 
            this.lblName2.AutoSize = true;
            this.lblName2.Location = new System.Drawing.Point(74, 128);
            this.lblName2.Name = "lblName2";
            this.lblName2.Size = new System.Drawing.Size(112, 25);
            this.lblName2.TabIndex = 4;
            this.lblName2.Text = "Enter name";
            // 
            // option1
            // 
            this.option1.AutoSize = true;
            this.option1.Location = new System.Drawing.Point(168, 252);
            this.option1.Name = "option1";
            this.option1.Size = new System.Drawing.Size(107, 29);
            this.option1.TabIndex = 5;
            this.option1.Text = "Option1";
            this.option1.UseVisualStyleBackColor = true;
            // 
            // option2
            // 
            this.option2.AutoSize = true;
            this.option2.Location = new System.Drawing.Point(423, 252);
            this.option2.Name = "option2";
            this.option2.Size = new System.Drawing.Size(112, 29);
            this.option2.TabIndex = 6;
            this.option2.Text = "Option 2";
            this.option2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.option2);
            this.Controls.Add(this.option1);
            this.Controls.Add(this.lblName2);
            this.Controls.Add(this.lblName1);
            this.Controls.Add(this.Lname);
            this.Controls.Add(this.btnHello);
            this.Controls.Add(this.Fname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Fname;
        private System.Windows.Forms.Button btnHello;
        private System.Windows.Forms.TextBox Lname;
        private System.Windows.Forms.Label lblName1;
        private System.Windows.Forms.Label lblName2;
        private System.Windows.Forms.CheckBox option1;
        private System.Windows.Forms.CheckBox option2;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace task3
{
    class Program
    {
        static void Main(string[] args)
        {
            //string path = "D:\\Semester 2\\OOP\\taskfile.txt";
            //StreamWriter filevariable = new StreamWriter(path, true);
            //filevariable.WriteLine("shahneela");
            //filevariable.Flush();
            //filevariable.Close();
            string path = "D:\\Semester 2\\OOP\\task.txt";
            if (File.Exists(path))
            {
                StreamReader filevariable = new StreamReader(path);
                string record;
                while ((record = filevariable.ReadLine()) != null)
                {
                    Console.WriteLine(record);
                }
                filevariable.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
            Console.ReadKey();
            //int n1;
            //int n2;
            //Console.Write("Enter 1st number: ");
            //n1 = int.Parse(Console.ReadLine());
            //Console.Write("Enter 2nd number: ");
            //n2 = int.Parse(Console.ReadLine());
            //int result = add(n1, n2);
            //Console.Write("Sum is {0}", result);
            //Console.Read();
        }
        //static int add (int num1, int num2)
        //{
        //    return num1 + num2;
        //}

    }
}

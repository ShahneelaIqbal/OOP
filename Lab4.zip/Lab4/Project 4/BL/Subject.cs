﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_4.BL
{
    class Subject
    {
        public string code;
        public int creditHours;
        public string subjectType;
        public int fee;

        public Subject(string code, int creditHours, string subjectType, int fee)
        {
            this.code = code;
            this.creditHours = creditHours;
            this.subjectType = subjectType;
            this.fee = fee;
        }
    }

}

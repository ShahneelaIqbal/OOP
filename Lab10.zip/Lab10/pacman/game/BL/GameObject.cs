﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.BL
{
    public class GameObject
    {
        public char DisplayCharacter;
        public GameCell currentCell;
        public  GameObjectType GameObjectType;

        //public GameObject() 
        //{

        //}

        public GameObject(GameObjectType type, char DisplayCharacter)
        {
            GameObjectType = type;
            this.DisplayCharacter = DisplayCharacter;
        }
        public static GameObjectType GetGameObjectType(char displayCharacter)
        {
            if (displayCharacter == '|' || displayCharacter == '#' || displayCharacter == '%')
            {
                return GameObjectType.Wall;
            }
            if (displayCharacter == '.')
            {
                return GameObjectType.Reward;
            }
            return GameObjectType.None;
        }
    }
}

﻿using Pro1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro1
{
    class Program
    {
        static void Main(string[] args)
        {
            //DayScholar std = new DayScholar();
            //std.name = "Shahneela Iqbal";
            //std.busNo = 1;
            //Console.WriteLine(std.name + " is allocated bus " + std.busNo);
            //Console.ReadKey();

            Hostelite obj = new Hostelite();
            obj.name = "Shahneela Iqbal";
            obj.roomNumber = 11;
            Console.WriteLine(obj.name + " is allocated room " + obj.roomNumber);
            Console.ReadKey();
        }
    }
}

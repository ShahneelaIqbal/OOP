﻿using Project1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<student> user = new List<student>();
            student information = info();
            float meritCalculate = information.calculateMerit();
            Console.WriteLine("Merit is:{0}", meritCalculate);
            bool eligible = information.scholarship(meritCalculate);
            if(eligible == true)
            {
                Console.WriteLine("You are eligible for scholarship");
            }
            else
            {
                Console.WriteLine("You are not eligible for scholarship");
            }
            Console.ReadKey();
        }
        static student info()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Roll Number: ");
            int rollNumber = int.Parse(Console.ReadLine()); 
            Console.WriteLine("Enter cGPA: ");
            float cGPA = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Matric Marks: ");
            int matricMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Fsc Marks: ");
            int fscMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Ecat Marks: ");
            int ecatMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Are you in studying in home town (yes/no): ");
            string homeTown = Console.ReadLine();
            Console.WriteLine("Are you in hostelite (true/false): ");
            bool isHostelite = bool.Parse(Console.ReadLine());
            student users = new student(name, rollNumber, cGPA, matricMarks, fscMarks, ecatMarks, homeTown, isHostelite);
            return users;
        }
        static void storeInList(List<student> user, student users)
        {
            user.Add(users);
        }
    }
}

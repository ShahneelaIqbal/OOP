﻿using Project_4.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<DegreeProgram> list = new List<DegreeProgram>();
            while (true)
            {
                int option = menu();
                if (option == 1)
                {
                    list.Add(addProgram());
                }
                else if (option == 2)
                {
                    Console.WriteLine("Please add student");
                    Console.ReadKey();
                }
                else if (option == 3)
                {
                    Console.WriteLine("Please add subject");
                    Console.ReadKey();
                }
                else if (option == 4)
                {
                    Console.WriteLine("merit: ");
                    Console.ReadKey();
                }

                else if (option == 9)
                {
                    break;
                }
            }
            Console.WriteLine("Thanks");
            Console.ReadKey();
        }

        static int menu()
        {
            Console.Clear();
            int opt;
            Console.WriteLine("1.Add Program");
            Console.WriteLine("2.Add Student");
            Console.WriteLine("3.Add Subject");
            Console.WriteLine("4.Generate merit");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("9.Exit");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("enter option");
            opt = int.Parse(Console.ReadLine());
            return opt;
        }
        static void header()
        {
            Console.WriteLine("------------------------------------");
            Console.WriteLine("----------------UMS-----------------");
            Console.WriteLine("------------------------------------");
        }
        static DegreeProgram addProgram()
        {
            Console.WriteLine("Enter degree program: ");
            string title = Console.ReadLine();
            Console.WriteLine("Enter degree program duration: ");
            int duration = int.Parse(Console.ReadLine());

            DegreeProgram obj = new DegreeProgram(title, duration);
            return obj;
        }
        static Student addStudent()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter age: ");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Fsc number: ");
            float fscMarks = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Ecat number: ");
            float ecatMarks = float.Parse(Console.ReadLine());

            Student studentObj = new Student(name, age, fscMarks, ecatMarks);
            return studentObj;
        }
        static Subject addSubject()
        {
            Console.WriteLine("Enter subject code: ");
            string code = Console.ReadLine();
            Console.WriteLine("Enter subject type: ");
            string subjectType = Console.ReadLine();
            Console.WriteLine("Enter credit hours: ");
            int creditHours = int.Parse(Console.ReadLine());
            Subject sub = new Subject();
            sub.code = code;
            sub.subjectType = subjectType;
            sub.creditHours = creditHours;

            return sub;
        }

        static Student StudentPresent(string name)
        {
            foreach (Student s in studentList)
            {
                if (name == s.name && s.regDegree != null)
                {
                    return s;
                }
                return null;
            }
        }
               
        static void calculateFeeForAll()
        {
            foreach (Student s in studentList)
            {
                if (s.regDegree != null)
                {
                    Console.WriteLine(s.name + " has " + s.getFee() + " fees");
                }

            }
        }

        static void registerSubjects(Students s)
        {
            Console.WriteLine("Enter how many subjects you want to register");
            int count = int.Parse(Console.ReadLine());
            for (int x = 0; x < count; x++)
            {
                Console.WriteLine("Enter the subject Code"); string code = Console.ReadLine();
                bool Flag = false;
                foreach (Subject sub in s.regDegree.subjects)
                {
                    if (code == sub.code && !(s.regSubject.Contains(sub)))
                    {
                        s.regStudentSubject(sub);
                        Flag = true;
                        break;
                    }
                }
                if (Flag == false)
                {
                    Console.WriteLine("Enter Valid Course");
                    x--;
                }
            }



        }
    }
}

﻿using Project2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2.UI
{
    class CoffeeShopUI
    {
        public static string menu()
        {
            Console.WriteLine("1. Add a Menu item");
            Console.WriteLine("2. View the Cheapest item in Menu");
            Console.WriteLine("3. View the Drink's Menu");
            Console.WriteLine("4. View the Food's Menu");
            Console.WriteLine("5. Order");
            Console.WriteLine("6. Fullfill the Order");
            Console.WriteLine("7. View the Order's List");
            Console.WriteLine("8. Total Amount");
            Console.WriteLine("9. Exit");
            string option = Console.ReadLine();
            return option;
        }

        public static MenuItem AddMenuItem()
        {
            Console.Write("Enter name :");
            string name = Console.ReadLine();
            Console.Write("Enter type :");
            string type = Console.ReadLine();
            Console.Write("Enter Price :");
            double price = double.Parse(Console.ReadLine());
            MenuItem newItem = new MenuItem(name, type, price);
            return newItem;
        }

        public static void CheapestItem(string item)
        {
            Console.WriteLine(item);
        }

        public static void DueAmount(double price)
        {
            Console.WriteLine(price);
        }

        public static void DrinkFoodMenu(List<string> menu)
        {
            foreach (string item in menu)
            {
                Console.WriteLine(item);
            }
        }

        public static string AddOrder()
        {
            Console.Write("Enter your Order : ");
            string order = Console.ReadLine();
            return order;
        }

        public static void OrdersFullfill(string order)
        {
            if (order != "fullfilled")
            {
                Console.WriteLine("The " + order + " is ready");
            }
            else
            {
                Console.WriteLine("All Orders Have been fullfilled...");
            }
        }

    }
}

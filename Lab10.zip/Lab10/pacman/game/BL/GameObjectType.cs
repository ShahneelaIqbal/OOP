﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.BL
{
     public enum GameObjectType
     {
        Wall,
        Player,
        Enemy,
        Reward,
        None
     }
}

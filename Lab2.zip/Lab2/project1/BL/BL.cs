﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.BL
{
    class students
    {
        public string name;
        public int roll_no;
        public float cgpa;
        public char isHostelide;
        public string department;

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tasks
{
    class Program
    {
        static void Main(string[] args)
        {
            task10();
        }
        static void task1()
        {
            Console.Write("HelloWorld!!");
            Console.Write("HelloWorld!!");
            Console.ReadKey();
        }
        static void task2()
        {
            Console.WriteLine("HelloWorld!!");
            Console.Write("HelloWorld!!");
            Console.ReadKey();
        }
        static void task3()
        {
            int num = 2;
            Console.WriteLine("Number is: ");
            Console.Write(num);
            Console.ReadKey();
        }
        static void task4()
        {
            string name = "Shahneela Iqbal";
            Console.WriteLine("Name is: ");
            Console.Write(name);
            Console.ReadKey();
        }
        static void task5()
        {
            char alpha = 'I';
            Console.WriteLine("Character is: ");
            Console.Write(alpha);
            Console.ReadKey();
        }
        static void task6()
        {
            float num = 3.3F;
            Console.WriteLine("Number is: ");
            Console.Write(num);
            Console.ReadKey();
        }
        static void task7()
        {
            string str;
            str = Console.ReadLine();
            Console.WriteLine("You have inputted: ");
            Console.Write(str);
            Console.ReadKey();
        }
        static void task8()
        {
            string str;
            float length;
            float area;
            Console.Write("Enter length: ");
            str = Console.ReadLine();
            length = float.Parse(str);
            area = length * length;
            Console.Write("Area is: ");
            Console.Write(area);
            Console.ReadKey();
        }
        static void task9()
        {
            string str;
            str = Console.ReadLine();
            int num = int.Parse(str);
            Console.WriteLine("The number is: ");
            Console.Write(num);
            Console.ReadKey();
        }
        static void task10()
        {
            string str;
            str = Console.ReadLine();
            float num = float.Parse(str);
            Console.WriteLine("The number is: ");
            Console.Write(num);
            Console.ReadKey();
        }
    }
}

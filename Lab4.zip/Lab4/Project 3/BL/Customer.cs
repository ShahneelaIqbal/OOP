﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3.BL
{
    class Customer
    {
        public string customerName;
        public string customerAddress;
        public string customerContact;
        public List<Product> products = new List<Product>();

        public List<Product> GetAllProducts()
        {
            return products;
        }
        public void addProduct(Product p)
        {
            products.Add(p);
        }

        public Customer(string customerName, string customerAddress, string customerContact)
        {
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.customerContact = customerContact;
        }
    }

}

﻿using Project2.BL;
using Project2.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2.DL
{
    class CoffeeShopDL
    {
        static CoffeeShop shop = new CoffeeShop("Grind On Coffee Shop");

        public static void readData()
        {
            shop.readFromFile();
        }

        public static void addItem()
        {
            MenuItem item = CoffeeShopUI.AddMenuItem();
            shop.addMenuItem(item);
        }

        public static void cheapItem()
        {
            string item = shop.cheapestItem();
            CoffeeShopUI.CheapestItem(item);
        }

        public static void drinkItem()
        {
            List<string> drink = shop.drinksOnly();
            CoffeeShopUI.DrinkFoodMenu(drink);
        }
        public static void foodItem()
        {
            List<string> Food = shop.foodOnly();
            CoffeeShopUI.DrinkFoodMenu(Food);
        }

        public static bool addOrder()
        {
            string order = CoffeeShopUI.AddOrder();

            if (!shop.addOrder(order))
            {
                return false;
            }
            return true;
        }

        public static void fulOrder()
        {
            string order = shop.fulfillOrder();
            if (order != null)
            {
                shop.updateOrders();
                CoffeeShopUI.OrdersFullfill(order);
            }
            else
            {
                CoffeeShopUI.OrdersFullfill("fullfilled");
            }
        }

        public static void drink()
        {
            List<string> order = shop.listOrders();
            CoffeeShopUI.DrinkFoodMenu(order);
        }
        public static void amount()
        {
            double amount = shop.dueAmount();
            CoffeeShopUI.DueAmount(amount);
        }

    }
}

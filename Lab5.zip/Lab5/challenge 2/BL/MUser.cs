﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.BL
{
    public class MUser
    {
        public string username;
        public string password;
        public string role;
        public MUser(string username, string password, string role)
        {
            this.username = username;
            this.password = password;
            this.role = role;

        }
        public MUser(string username, string password)
        {
            this.username = username;
            this.password = password;

        }
        public bool isAdmin()
        {
            if (role == "admin" || role == "Admin")
            {
                return true;
            }
            return false;
        }
        public bool isCustomer()
        {
            if (role == "customer" || role == "Customer")
            {
                return true;
            }
            return false;
        }
    }
}

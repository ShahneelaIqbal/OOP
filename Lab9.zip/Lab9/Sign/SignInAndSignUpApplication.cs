﻿using Sign.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sign
{
    public partial class SignInAndSignUpApplication : Form
    {
        public SignInAndSignUpApplication()
        {
            InitializeComponent();
            string path = "data.txt";

            if(MUserDL.readData(path))
            {
                MessageBox.Show("Data Loaded From File");
            }
            else
            {
                MessageBox.Show("Data not Loaded");
            }
        }

        private void lblSignInUp_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(SignIn.Checked)
            {
                Form moreForm = new SignInForm();
                moreForm.Show();
                SignIn.Checked = false;
            }

            else if(SignUp.Checked)
            {
                Form moreForm = new SignUpForm();
                moreForm.Show();
                SignUp.Checked = false;
            }
        }

        private void SignInAndSignUpApplication_Load(object sender, EventArgs e)
        {

        }
    }
}

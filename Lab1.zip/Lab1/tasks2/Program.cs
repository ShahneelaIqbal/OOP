﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tasks2
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            float priceOfMachine;
            int toyPrice;
            float answer;
            float answer1;
            float totalSavedMoney;
            float remaining;
            Console.Write("Enter age:");
            age = int.Parse(Console.ReadLine());
            Console.Write("Enter price of watching machine:");
            priceOfMachine = float.Parse(Console.ReadLine());
            Console.Write("Enter price of toy:");
            toyPrice = int.Parse(Console.ReadLine());
            answer = calculateMoneyEven(age);
            answer1 = calculateMoneyToy(age, toyPrice);
            totalSavedMoney = answer + answer1;
            if (totalSavedMoney > priceOfMachine)
            {
                remaining = totalSavedMoney - priceOfMachine;
                Console.WriteLine("Yes!");
                Console.Write(remaining);
            }
            else
            {
                remaining = priceOfMachine - totalSavedMoney;
                Console.WriteLine("No!");
                Console.Write(remaining);
            }
            Console.Read();
        }
        static void task1()
        {
            string input;
            float marks;
            Console.Write("Enter marks: ");
            input = Console.ReadLine();
            marks = float.Parse(input);
            if (marks > 50)
            {
                Console.Write("You are passed");
            }
            else
            {
                Console.Write("You are failed");
            }
            Console.ReadKey();
        }
        static void task2()
        {
            for (int x = 0; x < 5; x++)
            {
                Console.WriteLine("Welcome Jack");
            }
            Console.Read();
        }
        static void task3()
        {
            int num;
            int sum = 0;
            Console.Write("Write number: ");
            num = int.Parse(Console.ReadLine());
            while (num != -1)
            {
                sum = sum + num;
                Console.Write("Write number: ");
                num = int.Parse(Console.ReadLine());
            }
            Console.Write("The sum is {0}", sum);
            Console.Read();
        }
        static void task4()
        {
            int num;
            int sum = 0;
            do
            {
                Console.Write("Write number: ");
                num = int.Parse(Console.ReadLine());
                sum = sum + num;
            }

            while (num != -1);
            sum = sum + 1;
            Console.Write("The sum is {0}", sum);
            Console.Read();
        }
        static void task5()
        {
            int[] number = new int[3];
            for (int x = 0; x < 3; x++)
            {
                Console.Write("Enter number {0}:", x);
                number[x] = int.Parse(Console.ReadLine());
            }
            int largest = -1;
            for (int x = 0; x < 3; x++)
            {
                if (number[x] > largest)
                {
                    largest = number[x];
                }
            }
            Console.Write("The Largest Number is {0}", largest);
            Console.Read();
        }
        static float calculateMoneyEven(int age)
        {
            float saveMoney = 0;
            float money = 10.0F;
            int evenBirthday = 1;
            for (int count = 1; count <= age; count = count + 1)
            {
                if (count % 2 == 0)
                {
                    saveMoney = saveMoney + (evenBirthday * money);
                    saveMoney = saveMoney - 1;
                    evenBirthday = evenBirthday + 1;

                }

            }
            return saveMoney;
        }
        static float calculateMoneyToy(int age, int toyPrice)
        {
            float totalToy = 1;
            float totalToyPrice = 0;
            for (int count = 1; count <= age; count = count + 1)
            {
                if (count % 2 != 0)
                {
                    totalToyPrice = totalToyPrice + (totalToy * toyPrice);

                }

            }
            return totalToyPrice;
        }
    }
}


    


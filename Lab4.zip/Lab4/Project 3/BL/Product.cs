﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3.BL
{
    class Product
    {
        public string name;
        public string category;
        public int price;

        public Product(string name, string category, int price)
        {
            this.name = name;
            this.category = category;
            this.price = price;
        }

        public float calculatetax()
        {
            float tax = 0;
            if(category == "fruit" || category == "Fruit")
            {
                tax = this.price * 0.2F;
                return tax;
            }
            else if (category == "grocery" || category == "Grocery")
            {
                tax = this.price * 0.3F;
                return tax;
            }
            return tax;
        }
    }

}

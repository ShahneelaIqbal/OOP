﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2
{
    class shop
    {
        public string id;
        public string name;
        public float price;
        public string category;
        public string brandName;
        public string country;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2.BL
{
    class book
    {
        public string author;
        public int page;
        public List<string> chapters = new List<string> {"End War", "Ghost Protocol", "Fallout" };
        public int bookMarks;
        public int price;

        public book (string author, int page, int bookMarks, int price)
        {
            this.author = author;
            this.page = page;
            this.bookMarks = bookMarks;
            this.price = price;
        }
        public int getBookMark()
        {
            int mark;
            mark = this.bookMarks;
            return mark;
        }
        public void setBookMark(int pageNumber)
        {
            bookMarks = pageNumber;
        }
        public int priceOfBook()
        {
            int pr;
            pr = this.price;
            return pr;
        }
        public void newPrice(int newPrice)
        {
            price = newPrice;
        }
        public string getChapter(int number)
        {
            for (int i = 0; i < chapters.Count; i++)
            {
                if (i == number)
                {
                    return chapters[i];
                }
            }
            return null;
        }

    }
}

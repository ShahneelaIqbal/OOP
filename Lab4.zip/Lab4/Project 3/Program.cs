﻿using Project_3.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> customers = new List<Customer>();
            List<Product> products = new List<Product>();
            int option;
            do
            {
                option = menu();
                if (option == 1)
                {
                    Customer data = customerData(customers);
                    storeDataInCustomerList(customers, data);
                    Console.WriteLine("Enter 1 to add product");
                    int choice = int.Parse(Console.ReadLine());
                    Console.WriteLine("How many products do you want to add: ");
                    int proValue = int.Parse(Console.ReadLine());
                    for (int x = 0; x < proValue; x++)
                    {
                        if (choice == 1)
                        {
                            Product dataP = productData(products);
                            storeDataInProductList(products, dataP);
                            data.addProduct(dataP);
                            float tax = dataP.calculatetax();
                            Console.WriteLine("The tax is: {0}", tax);
                        }
                    }

                }
                else
                {
                    Console.WriteLine("Please enter correct option");
                }

            }
            while (option != 2);
            Console.ReadKey();
        }
        static int menu()
        {
            int option;
            Console.WriteLine("1.Customer");
            Console.WriteLine("Enter your choice");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static Customer customerData(List<Customer> customers)
        {
            Console.WriteLine("Enter name: ");
            string customerName = Console.ReadLine();
            Console.WriteLine("Enter address: ");
            string customerAddress = Console.ReadLine();
            Console.WriteLine("Enter contact: ");
            string customerContact = Console.ReadLine();

            Customer user = new Customer(customerName, customerAddress, customerContact);
            return user;
        }
        static void storeDataInCustomerList(List<Customer> customers, Customer user)
        {
            customers.Add(user);
        }
        static Product productData(List<Product> products)
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter category: ");
            string category = Console.ReadLine();
            Console.WriteLine("Enter price: ");
            int price = int.Parse(Console.ReadLine());

            Product p = new Product(name, category, price);
            return p;
        }
        static void storeDataInProductList(List<Product> products, Product p)
        {
            products.Add(p);
        }
    }
}

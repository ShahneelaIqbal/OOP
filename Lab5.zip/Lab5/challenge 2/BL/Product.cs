﻿using Challenge3.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.BL
{
    public class Product
    {
        public string productName;
        public int productPrice;
        public string productCategory;
        public int productQuantity;
        public Product(string productName, int productPrice, string productCategory, int productQuantity)
        {
            this.productName = productName;
            this.productPrice = productPrice;
            this.productCategory = productCategory;
            this.productQuantity = productQuantity;
        }
        public Product(string productName, string productCategory, int productQuantity)
        {
            this.productName = productName;

            this.productCategory = productCategory;
            this.productQuantity = productQuantity;
        }
        public Product(int productPrice, string productCategory)
        {

            this.productPrice = productPrice;
            this.productCategory = productCategory;
        }

        public static List<Product> sortProductByPrice()
        {
            List<Product> sortedProductList = new List<Product>();
            foreach (Product s in ProductCRUD.products)
            {
                sortedProductList = ProductCRUD.products.OrderByDescending(o => o.productPrice).ToList();

                return sortedProductList;
            }
            return null;
        }
        public float calculateTax()
        {
            float tax = 0;
            if (productCategory == "fruit" || productCategory == "Fruit")
            {
                tax = this.productPrice * 0.1F;

            }
            else if (productCategory == "grocery" || productCategory == "Grocery")
            {
                tax = this.productPrice * 0.05F;

            }
            else
            {
                tax = this.productPrice * 0.15F;


            }
            return tax;
        }




    }
}

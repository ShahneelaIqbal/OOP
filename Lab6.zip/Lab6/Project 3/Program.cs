﻿using Project_3.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] shape = new char[5, 5] { { ' ', ' ', '*', ' ', ' ' }, { ' ', '*', '*', '*', ' ' }, { '*', '*', '*', '*', '*' }, { ' ', '*', '*', '*', ' ' }, { ' ', ' ', '*', ' ', ' ' } };

            Boundary b = new Boundary(new Point(0, 0), new Point(90, 0), new Point(0, 90), new Point(90, 90));
            GameObject g1 = new GameObject(shape, new Point(5, 5), b, "righttoleft");
            GameObject g2 = new GameObject(shape, new Point(15, 20), b, "lefttoright");
            GameObject g3 = new GameObject(shape, new Point(30, 30), b, "patrolleft");
            GameObject g4 = new GameObject(shape, new Point(15, 15), b, "parabola");

            List<GameObject> game = new List<GameObject>();
            game.Add(g4);

            while (true)
            {
                Thread.Sleep(100);
                Console.Clear();
                foreach (GameObject g in game)
                {
                    g.erase();
                    g.move();
                    g.draw();
                }
            }


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro4.BL
{
    public class Square : Shape
    {
        protected int side;
        public Square(string name, int side) : base(name)
        {
            this.side = side;
        }
        public override double getArea()
        {
            return side * side;
        }
        public override string toString()
        {
            return base.toString() + " and its area is: " + (side * side);
        }
    }
}

﻿using Challenge3.BL;
using Challenge3.DL;
using Challenge3.UI;
using System;
using System.Collections.Generic;

namespace Challenge3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            int option;
            do
            {
                option = menu();
                clearScreen();
                Console.Clear();

                if (option == 1)
                {
                    Console.Clear();
                    MUser user = MUserUI.takeInputWithRole();
                    if (user != null)
                    {
                        MUserCRUD.storeDataInList(user);
                        clearScreen();
                    }
                    Console.Clear();
                }
                else if (option == 2)
                {
                    Console.Clear();
                    MUser user = MUserUI.takeInputWithoutRole();
                    if (user != null)
                    {
                        user = MUserCRUD.SignIn(user);
                        if (user == null)
                        {
                            Console.WriteLine("Invalid USER");

                        }
                        else if (user.isAdmin())
                        {
                            Console.WriteLine("**************************");
                            Console.WriteLine("        ADMIN MENU         ");
                            Console.WriteLine("**************************");

                            int category;
                            do
                            {
                                Console.Clear();
                                category = AdminMenu();
                                clearScreen();
                                if (category == 1)
                                {
                                    Console.Clear();
                                    Product p2 = ProductUI.addProduct();
                                    ProductCRUD.storeInList(p2);
                                    clearScreen();
                                    Console.Clear();

                                }
                                else if (category == 2)
                                {
                                    Console.Clear();
                                    ProductUI.viewAllProduct();
                                    clearScreen();
                                    Console.Clear();

                                }
                                else if (category == 3)
                                {
                                    Console.Clear();
                                    List<Product> sortedProductList = new List<Product>();
                                    sortedProductList = Product.sortProductByPrice();
                                    clearScreen();
                                    Console.Clear();

                                }
                                else if (category == 4)
                                {
                                    Console.Clear();
                                    ProductUI.productTax();
                                    clearScreen();
                                    Console.Clear();

                                }
                                else if (category == 5)
                                {
                                    Console.Clear();
                                    Product p3 = ProductUI.orderedProduct();

                                    clearScreen();


                                }
                                else if (category == 6)
                                {
                                    break;
                                }

                            }
                            while (category < 6);
                            Console.ReadKey();
                        }
                        else if (user.isCustomer())
                        {
                            Console.WriteLine("**************************");
                            Console.WriteLine("        CUSTOMER  MENU         ");
                            Console.WriteLine("**************************");

                            int category1;
                            do
                            {
                                Console.Clear();
                                category1 = CustomerMenu();
                                clearScreen();
                                if (category1 == 1)

                                {
                                    Console.Clear();
                                    ProductUI.viewAllProduct();
                                    clearScreen();
                                    Console.Clear();

                                }


                                else if (category1 == 2)
                                {
                                    Console.Clear();
                                    ProductUI.buyProduct();
                                    clearScreen();
                                    Console.Clear();


                                }
                                else if (category1 == 3)
                                {
                                    Console.Clear();
                                    float generic = ProductUI.genericVoice();
                                    clearScreen();
                                    Console.Clear();

                                }
                                else if (category1 == 4)
                                {
                                    break;


                                }

                            }
                            while (category1 < 4);
                            Console.ReadKey();



                        }

                    }
                }
                else
                {
                    Console.WriteLine("USER MENU");
                }

                Console.Clear();




            }
            while (option < 3);
            Console.ReadKey();

        }
        static int menu()
        {
            Console.WriteLine("****MENU *****");
            Console.WriteLine("1.SIGN UP");
            Console.WriteLine("2.SIGN IN ");
            Console.WriteLine("3.Exit");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static void clearScreen()
        {
            Console.WriteLine("Press any to continue ....");
            Console.ReadKey();
        }
        static int AdminMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("        ADMIN MENU         ");
            Console.WriteLine("**************************");
            Console.WriteLine("1.Add Product ");
            Console.WriteLine("2.View all Products");
            Console.WriteLine("3.Find product with highest Price");
            Console.WriteLine("4.View sales tax of all products");
            Console.WriteLine("5.Product to be ordered");
            Console.WriteLine("6.EXIT");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        static int CustomerMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("        CUSTOMER  MENU         ");
            Console.WriteLine("**************************");
            Console.WriteLine("1.View all Products");
            Console.WriteLine("2.Buy the products");
            Console.WriteLine("3.Generatic invoice");
            Console.WriteLine("4.EXIT");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
    }
}

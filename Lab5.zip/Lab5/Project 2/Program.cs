﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_2
{
    class Program
    {
        class student
        {
            public string name;
            public int roll;
            public int ecat;
            public student (string name, int roll, int ecat)
            {
                this.name = name;
                this.roll = roll;
                this.ecat = ecat;
            }
        }
        static void Main(string[] args)
        {
            student s1 = new student("Sheela", 159, 150);
            student s2 = new student("noor", 140, 200);
            List<student> studentList = new List<student>() { s1, s2 };
            List<student> sortedList = studentList.OrderBy(o => o.roll).ToList();
            foreach(student s in sortedList)
            {
                Console.WriteLine("{0}\t {1}\t {2}",s.name, s.roll, s.ecat);
            }
            Console.ReadKey();
        }
    }
}

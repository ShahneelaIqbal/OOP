﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5.clock
{
    class clockType
    {
        public clockType(int h, int m, int s)
        {
            hours = h;
            minutes = m;
            second = s;
        }
        public clockType(int h)
        {
            hours = h;
        }
        public clockType(int h, int m)
        {
            hours = h;
            minutes = m;
        }
        public clockType()
        {
            hours = 0;
            minutes = 0;
            second = 0;
        }
        public int elapsed()
        {
            int time = ((hours * 3600) + (minutes * 60) + second);
            return time;
        }
        public int remain(int result)
        {
            int timeRemain = 86400 - result;
            return timeRemain;
        }
        public void difference(int h, int m, int s)
        {
            if (hours > h)
            {
                hours = hours - h;
            }
            else if (h > hours)
            {
                hours = h - hours;
            }
            if (minutes > m)
            {
                minutes = minutes - m;
            }
            else if (m > minutes)
            {
                minutes = m - minutes;
            }
            if (second > s)
            {
                second = second - s;
            }
            else if (s > second)
            {
                second = s - second;
            }
            Console.WriteLine("The time difference is: ");
            Console.Write("{0} : {1} : {2}", hours, minutes, second);
        }
        int hours;
        int second;
        int minutes;
    }
        
    
}

﻿using project2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2
{
    class Program
    {
        static void Main(string[] args)
        {
            student s1 = new student();
            s1.name = "Ethan";
            student s2 = new student(s1);
            Console.WriteLine(s1.name);
            Console.WriteLine(s2.name);
            //student s1 = new student("Ethan", 1009, 1060, 230, 80.5F);
            //Console.WriteLine(s1.name);
            //Console.WriteLine(s1.matric);
            //Console.WriteLine(s1.fsc);
            //Console.WriteLine(s1.ecat);
            //Console.WriteLine(s1.aggregate);
            //student s2 = new student("Hunt", 1030, 1050, 250, 81.2F);
            //Console.WriteLine(s2.name);
            //Console.WriteLine(s2.matric);
            //Console.WriteLine(s2.fsc);
            //Console.WriteLine(s2.ecat);
            //Console.WriteLine(s2.aggregate);
            Console.Read();

        }
    }
}

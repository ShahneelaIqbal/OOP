﻿using Pro1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro1
{
    class Program
    {
        static void Main(string[] args)
        {
            Cylinder obj = new Cylinder();
            double r = obj.getRadius();
            Console.WriteLine("Radius is: " + r);
            Console.WriteLine("Enter New radius: ");
            double radius = double.Parse(Console.ReadLine());
            obj.setRadius(radius);
            string c = obj.getColor();
            Console.WriteLine("Color is: " + c);
            Console.WriteLine("Enter New color: ");
            string color = Console.ReadLine();
            obj.setColor(color);
            double area = obj.getArea();
            Console.WriteLine("Area is: " + area);

            double h = obj.getHeight();
            Console.WriteLine("Height is: " + h);
            Console.WriteLine("Enter New Height: ");
            double height = double.Parse(Console.ReadLine());
            obj.setHeight(height);
            double volume = obj.getVolume();
            Console.WriteLine("Volume is: " + volume);

            string all = obj.toString();
            Console.WriteLine(all);
            Console.ReadKey();
        }
    }
}

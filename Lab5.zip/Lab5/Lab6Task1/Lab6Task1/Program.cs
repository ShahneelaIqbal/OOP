﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab6Task1.BL;
using Lab6Task1.UI;
namespace Lab6Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            MyLine line=new MyLine();
            int option = 0;
            do
            {
                Console.Clear();  
                option = Menu();
                if (option == 1)
                {
                    Console.WriteLine("Make a Line...");
                    MyPoint begin = MyLineUI.GetPointFromUser("Begin");
                    line.setBegin(begin);
                    MyPoint end = MyLineUI.GetPointFromUser("End");
                    line.setEnd(end);
                }
                else if (option == 2)
                {
                    Console.WriteLine("Update the Begin Point");
                    MyPoint begin = MyLineUI.GetPointFromUser("Begin");
                    line.setBegin(begin);
                }
                else if (option == 3)
                {
                    Console.WriteLine("Update the End Point");
                    MyPoint end = MyLineUI.GetPointFromUser("End");
                    line.setEnd(end);
                }
                else if (option == 4)
                {
                    MyLineUI.ShowBeginPoint(line, "Begin");
                }
                else if (option == 5)
                {
                    MyLineUI.ShowEndPoint(line, "End");
                }
                else if (option == 6)
                {
                    MyLineUI.getLength(line);
                }
                else if (option == 7)
                {
                    MyLineUI.getGradient(line);
                }
                else if (option == 8)
                {
                    MyLineUI.distanceOfPointFromZero(line.begin, "Begin");
                }
                else if (option == 9)
                {
                    MyLineUI.distanceOfPointFromZero(line.end, "End");
                }
                else if(option ==10)
                {
                    break;
                }
                Console.ReadKey();

            }
            while (option != 10);
        }

        static int Menu()
        {
            int option;
            Console.WriteLine("1.Make a Line");
            Console.WriteLine("2.Update the begin point");
            Console.WriteLine("3.Update the end point");
            Console.WriteLine("4.Show the begin Point");
            Console.WriteLine("5.Show the end point");
            Console.WriteLine("6.Get the Length of the line");
            Console.WriteLine("7.Get the Gradient of the Line");
            Console.WriteLine("8.Find the distance of begin point from zero coordinates");
            Console.WriteLine("9.Find the distance of end point from zero coordinates");
            Console.WriteLine("10.Exit");
            Console.WriteLine("Enter your option; ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
    }
}

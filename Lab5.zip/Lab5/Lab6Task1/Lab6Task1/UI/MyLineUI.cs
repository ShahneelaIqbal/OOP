﻿using Lab6Task1.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6Task1.UI
{
    public class MyLineUI
    {
        static public MyPoint GetPointFromUser(string point)
        {
           
            int x = getPoint(point + " point x coordinate ");
            int y = getPoint(point + " point y coordinate");
            MyPoint myPoint = new MyPoint(x,y);
            return myPoint;
        }
        static int getPoint(string point)
        {
            Console.Write("Enter the "+ point + " : ");
            return int.Parse(Console.ReadLine());
        }
        public MyLine getLineFromUser()
        {
            MyPoint begin = GetPointFromUser("begin");
            MyPoint end = GetPointFromUser("end");
            MyLine myLine = new MyLine(begin, end);
            return myLine;
        }
        public static void ShowBeginPoint(MyLine line,string point)
        {
            Console.Write(point + " Point x is " + line.getBegin().getX());
            Console.Write(point + " Point y is " + line.getBegin().getY());
        }
        public static void ShowEndPoint(MyLine line, string point)
        {
            Console.Write(point + " Point x is " + line.getEnd().getX());
            Console.Write(point + " Point y is " + line.getEnd().getY());
        }
        public static void getLength(MyLine line)
        {
            Console.WriteLine("Length of the Line is..."+ line.getLength()+"cm.");         
        }
        public static void getGradient(MyLine line)
        {
            Console.WriteLine("Gradient of the Line is..." + line.getGradient() + "cm.");
        }
        public static void distanceOfPointFromZero(MyPoint point,string p)
        {
            Console.WriteLine("Distance of "+p+" from zero CoOrdinate is : "+point.distanceFromZero());
        }
    }
}

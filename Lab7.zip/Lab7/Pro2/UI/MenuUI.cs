﻿using Pro2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro2.UI
{
    class MenuUI
    {
        public static int menu()
        {
            int option = 0;
            Console.Clear();

            Console.WriteLine("1. Add all information");
            Console.WriteLine("2. Set seat height");
            Console.WriteLine("3. Set candence");
            Console.WriteLine("4. Set gear");
            Console.WriteLine("5. Apply break");
            Console.WriteLine("6. Speed up");
            Console.WriteLine("7. Exit");
            Console.WriteLine("Enter option: ");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        
        public static MountainBike info()
        {
            Console.WriteLine("Enter seat height: ");
            int seatHeight = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter candence: ");
            int candence = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter speed: ");
            int speed = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter gear: ");
            int gear = int.Parse(Console.ReadLine());

            MountainBike std = new MountainBike(seatHeight, candence, speed, gear);
            return std;
        }

        public static int setHeight()
        {
            Console.WriteLine("Enter new height: ");
            int height = int.Parse(Console.ReadLine());

            return height;
        }

        public static int setCandence()
        {
            Console.WriteLine("Enter new candence: ");
            int candence = int.Parse(Console.ReadLine());

            return candence;
        }

        public static int setGear()
        {
            Console.WriteLine("Enter new gear: ");
            int gear = int.Parse(Console.ReadLine());

            return gear;
        }

        public static int setBreak()
        {
            Console.WriteLine("Enter decrement in speed: ");
            int decrement = int.Parse(Console.ReadLine());

            return decrement;
        }

        public static int setSpeedUp()
        {
            Console.WriteLine("Enter increment in speed: ");
            int increment = int.Parse(Console.ReadLine());

            return increment;
        }
    }
}

﻿using Sign.BL;
using Sign.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sign
{
    public partial class SignInForm : Form
    {
        public SignInForm()
        {
            InitializeComponent();
        }

        private void clearDataFromForm()
        {
            txtName.Text = "";
            txtPassword.Text = "";
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblSignInUp_Click(object sender, EventArgs e)
        {

        }

        private void SignIn_Load(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string password = txtPassword.Text;
            MUser user = new MUser(username, password);
            MUser validUser = MUserDL.SignIn(user);
            if (validUser != null)
            {
                MessageBox.Show("User is valid");
            }
            else
            {
                MessageBox.Show("User is not valid");
            }
            clearDataFromForm();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro1.BL
{
    class Hostelite : Student
    {
        public int roomNumber;
        public bool isFridgeAvailable;
        public bool isInternetAvailale;

        //public int getHostelFee()
        //{
        //    int fee = 0;
        //    if()
        //}
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2.BL
{
    class CoffeeShop
    {
        public string name;
        public List<MenuItem> menu;
        public List<string> orders;

        public CoffeeShop(string name)
        {
            this.name = name;
            menu = new List<MenuItem>();
            orders = new List<string>();
        }

        public void addMenuItem(MenuItem item)
        {
            menu.Add(item);
        }

        public bool addOrder(string order)
        {
            foreach (MenuItem item in menu)
            {
                if (item.name.ToLower() == order.ToLower())
                {
                    orders.Add(order);
                    return true;
                }
            }
            return false;
        }

        public void updateOrders()
        {
            orders.RemoveAt(0);
        }

        public string fulfillOrder()
        {
            if (orders.Count != 0)
            {
                return orders[0];
            }
            else
            {
                return null;
            }

        }

        public List<string> listOrders()
        {
            if (orders.Count != 0)
            {
                return orders;
            }
            return null;
        }

        public double dueAmount()
        {
            double amount = 0;
            foreach (string order in orders)
            {
                foreach (MenuItem item in menu)
                {
                    if (order == item.name)
                    {
                        amount = amount + item.price;
                    }
                }
            }
            return amount;
        }

        public string cheapestItem()
        {
            double price = 1000;
            string cheapestItem = "";
            foreach (MenuItem item in menu)
            {
                if (item.price < price)
                {
                    price = item.price;
                    cheapestItem = item.name;
                }
            }
            return cheapestItem;
        }

        public List<string> drinksOnly()
        {
            List<string> drinks = new List<string>();
            foreach (MenuItem item in menu)
            {
                if (item.type.ToLower() == "drink")
                {
                    drinks.Add(item.name);
                }
            }
            return drinks;
        }

        public List<string> foodOnly()
        {
            List<string> foods = new List<string>();
            foreach (MenuItem item in menu)
            {
                if (item.type.ToLower() == "food")
                {
                    foods.Add(item.name);
                }
            }
            return foods;
        }

        public void readFromFile()
        {
            {
                StreamReader file = new StreamReader("CoffeeShop.txt");
                string line;
                while ((line = file.ReadLine()) != null)
                {
                    string[] temp = line.Split(',');
                    MenuItem item = new MenuItem(temp[0], temp[1], double.Parse(temp[2]));
                    menu.Add(item);
                }
                file.Close();
            }

        }

        public void storeinFile()
        {
            StreamWriter file = new StreamWriter("CoffeeShop.txt");
            foreach (MenuItem item in menu)
            {
                file.WriteLine(item.name + "," + item.type + "," + item.price);
            }
            file.Flush();
            file.Close();
        }

    }
}

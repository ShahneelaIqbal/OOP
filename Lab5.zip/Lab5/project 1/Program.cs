﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    class Program
    {
        class student
        {
            public string name;
            public int roll;
            public int ecat;
        }
        public student(string name, int roll, int ecat)

        static void Main(string[] args)
        {

            student s1 = new student("Shahneela", 159, 150);



            //List<string> list = new List<string>() { "Bilal", "Ahmend" };
            //List<float> floatList = new List<float>() { 10.4F, 10.7F, 10.0F};
            //floatList.Sort();
            //foreach(float i in floatList)
            //{
            //    Console.WriteLine(i);
            //}
            //Console.ReadKey();
        }
    }
}

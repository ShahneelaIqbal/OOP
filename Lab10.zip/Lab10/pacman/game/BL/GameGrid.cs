﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.BL
{
    public class GameGrid
    {
        public GameCell[,] gameCells;
        public int rows;
        public int cols;

        public GameGrid(string filename, int rows, int cols)
        {
            this.rows = rows;
            this.cols = cols;
            LoadGrid(filename);
        }

        private void LoadGrid(string fileName)
        {
            StreamReader file = new StreamReader(fileName);
            string line = " ";
            for (int row = 0; row < rows; row++)
            {
                line = file.ReadLine();
                for (int col = 0; col < cols; col++)
                {
                    GameCell cell = new GameCell(row, col, this);
                    char displayCharacter = line[col];
                    GameObjectType type = GameObject.GetGameObjectType(displayCharacter);
                    GameObject gameObject = new GameObject(type, displayCharacter);
                    cell.currentGameObject = gameObject;
                    GameCell[row, col] = cell;
                }
            }
            file.Close();
        }
        public GameCell GetCell(int x, int y)
        {
            return GameCell[x, y];
        }

    }
}

﻿using Pro2.BL;
using Pro2.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro2
{
    class Program
    {
        static void Main(string[] args)
        {
            MountainBike obj = new MountainBike();
            int opt;
            do
            {
                opt = MenuUI.menu();
                if (opt == 1)
                {
                    Console.Clear();
                    MenuUI.info();
                }

                if (opt == 2)
                {
                    Console.Clear();
                    int height = MenuUI.setHeight();
                    obj.setHeight(height);
                                      
                }

                if (opt == 3)
                {
                    Console.Clear();
                    int candence = MenuUI.setCandence();
                    obj.setCandence(candence);
                    obj.showCandence();
                    Console.ReadKey();
                }

                if(opt == 4)
                {
                    Console.Clear();
                    int gear = MenuUI.setGear();
                    obj.setGear(gear);
                    obj.showGear();
                    Console.ReadKey();

                }

                if (opt == 5)
                {
                    Console.Clear();
                    int decrement = MenuUI.setBreak();
                    obj.applyBrake(decrement);
                    int speed = obj.showDecre();
                    Console.WriteLine(speed);
                    Console.ReadKey();
                }

                if (opt == 6)
                {
                    Console.Clear();
                    int increment = MenuUI.setSpeedUp();
                    obj.speedUp(increment);
                    int speed = obj.showIncre();
                    Console.WriteLine(speed);
                    Console.ReadKey();
                }
            }
            while (opt != 7);
            Console.WriteLine("Shukriya..");
            Console.ReadKey();
        }
    }
}

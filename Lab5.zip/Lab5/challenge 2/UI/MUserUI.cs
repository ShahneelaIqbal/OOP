﻿using Challenge3.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.UI
{
    public class MUserUI
    {
        public static MUser takeInputWithRole()
        {
            Console.WriteLine("enter username :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter password :");
            string password = Console.ReadLine();
            Console.WriteLine("enter your role :");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                MUser s1 = new MUser(name, password, role);
                return s1;
            }
            return null;

        }
        public static MUser takeInputWithoutRole()
        {
            Console.WriteLine("enter username :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter password :");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                MUser s2 = new MUser(name, password);
                return s2;
            }
            return null;


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1
{
    class Program
    {
        static void Main(string[] args)
        {
            student s1 = new student();
            student s2 = new student();
            Console.WriteLine(s1.name);
            Console.WriteLine(s1.matric);
            Console.WriteLine(s1.fsc);
            Console.WriteLine(s1.ecat);
            Console.WriteLine(s1.aggregate);
            Console.WriteLine(s2.name);
            Console.WriteLine(s2.matric);
            Console.WriteLine(s2.fsc);
            Console.WriteLine(s2.ecat);
            Console.WriteLine(s2.aggregate);
            Console.Read();
        }
    }
}

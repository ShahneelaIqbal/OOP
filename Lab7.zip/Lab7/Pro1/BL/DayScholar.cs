﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro1.BL
{
    class DayScholar : Student
    {
        public string pickUpPoint;
        public int busNo;
        public int pickUpDistance;
    }
}

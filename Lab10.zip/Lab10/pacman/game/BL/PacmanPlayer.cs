﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.BL
{
    //public class PacmanPlayer : GameObject
    //{
    //    public PacmanPlayer() : base()
    //    {

    //    }

    //    public static void movePacManUp(char[,] maze, ref int pacmanX, ref int pacmanY)
    //    {
    //        if (maze[pacmanX - 1, pacmanY] == ' ' || maze[pacmanX - 1, pacmanY] == '.')
    //        {
    //            maze[pacmanX, pacmanY] = ' ';
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            Console.Write(" ");
    //            pacmanX = pacmanX - 1;
    //            if (maze[pacmanX, pacmanY] == '.')
    //            {
    //                //calculateScore();
    //            }
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            maze[pacmanX, pacmanY] = 'P';
    //            Console.Write("P");

    //        }
    //    }

    //    public static void movePacManDown(char[,] maze, ref int pacmanX, ref int pacmanY)
    //    {
    //        if (maze[pacmanX + 1, pacmanY] == ' ' || maze[pacmanX + 1, pacmanY] == '.')
    //        {
    //            maze[pacmanX, pacmanY] = ' ';
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            Console.Write(" ");
    //            pacmanX = pacmanX + 1;
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            if (maze[pacmanX, pacmanY] == '.')
    //            {
    //                //calculateScore();
    //            }
    //            maze[pacmanX, pacmanY] = 'P';
    //            Console.Write("P");

    //        }
    //    }

    //    public static void movePacManLeft(char[,] maze, ref int pacmanX, ref int pacmanY)
    //    {
    //        if (maze[pacmanX, pacmanY - 1] == ' ' || maze[pacmanX, pacmanY - 1] == '.')
    //        {
    //            maze[pacmanX, pacmanY] = ' ';
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            Console.Write(" ");
    //            pacmanY = pacmanY - 1;
    //            if (maze[pacmanX, pacmanY] == '.')
    //            {
    //                //calculateScore();
    //            }
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            maze[pacmanX, pacmanY] = 'P';
    //            Console.Write("P");

    //        }
    //    }
    //    public static void movePacManRight(char[,] maze, ref int pacmanX, ref int pacmanY)
    //    {
    //        if (maze[pacmanX, pacmanY + 1] == ' ' || maze[pacmanX, pacmanY + 1] == '.')
    //        {
    //            maze[pacmanX, pacmanY] = ' ';
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            Console.Write(" ");
    //            pacmanY = pacmanY + 1;
    //            if (maze[pacmanX, pacmanY] == '.')
    //            {
    //                //calculateScore();
    //            }
    //            Console.SetCursorPosition(pacmanY, pacmanX);
    //            maze[pacmanX, pacmanY] = 'P';
    //            Console.Write("P");

    //        }
    //    }
    }
}

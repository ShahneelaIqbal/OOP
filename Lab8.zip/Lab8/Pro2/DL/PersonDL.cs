﻿using Pro2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro2.DL
{
    class PersonDL
    {
        public static List<Person> persontList = new List<Person>();

        public static Student takeStudentInput()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter address: ");
            string address = Console.ReadLine();
            Console.WriteLine("Enter program: ");
            string program = Console.ReadLine();
            Console.WriteLine("Enter year: ");
            int year = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter fee: ");
            double fee = double.Parse(Console.ReadLine());
            Student student = new Student(name, address, program, year, fee);
            return student;
        }
        public static Staff takeStaffInput()
        {
            Console.WriteLine("Enter name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter address: ");
            string address = Console.ReadLine();
            Console.WriteLine("Enter school name: ");
            string school = Console.ReadLine();
            Console.WriteLine("Enter pay: ");
            double pay = double.Parse(Console.ReadLine());
            Staff staff = new Staff(name, address, school, pay);
            return staff;
        }
        public static void addIntoList(Person p)
        {
            persontList.Add(p);
        }
    }
}

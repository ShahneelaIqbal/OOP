﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2.BL
{
    class MenuItem
    {
        public string name;
        public string type;
        public double price;

        public MenuItem(string name, string type, double price)
        {
            this.name = name;
            this.price = price;
            this.type = type;
        }

    }
}

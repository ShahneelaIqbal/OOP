﻿using Pro3.BL;
using Pro3.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pro3
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 2; i++)
            {
                Dog dog = AnimalDL.takeDogName();
                AnimalDL.addIntoList(dog);
                Cat cat = AnimalDL.takeCatName();
                AnimalDL.addIntoList(cat);
                string dogString = dog.toString();
                Console.WriteLine(dogString);
                dog.greets();

                string catString = cat.toString();
                Console.WriteLine(catString);
                cat.greets();

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6Task1.BL
{
    public class MyLine
    {
        public MyLine(MyPoint begin,MyPoint end)
        {
            this.begin = begin;
            this.end = end;
        }
        public MyLine()
        { }
        public  MyPoint begin;
        public MyPoint end;
        public MyPoint getBegin()
        {
            return begin;
        }
        public void setBegin(MyPoint begin)
        {
            this.begin = begin;
        }
        public MyPoint getEnd()
        {
            return end;
        }
        public void setEnd(MyPoint end)
        {
            this.end = end;
        }
        public double getLength()
        {
            double length = (Math.Pow(this.begin.x - end.x, 2) + Math.Pow(this.begin.y - end.y, 2));
            length = Math.Sqrt(length);
            return length;
        }
        public double getGradient()
        {
            int numenator = this.end.y - this.begin.y;
            int denominator= this.end.x - this.begin.x;
            double slope = numenator / denominator;
            return slope;
        }
    }
}

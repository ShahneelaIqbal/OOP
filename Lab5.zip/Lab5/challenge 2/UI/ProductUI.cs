﻿using Challenge3.BL;
using Challenge3.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.UI
{
    public class ProductUI
    {
        public static Product addProduct()
        {

            Console.WriteLine("Enter product name :");
            string productName = Console.ReadLine();
            Console.WriteLine("Enter product price :");
            int productPrice = int.Parse(Console.ReadLine());
            Console.WriteLine("enter product category :");
            string productCategory = Console.ReadLine();
            Console.WriteLine("Enter product  Quantity :");
            int productQuantity = int.Parse(Console.ReadLine());
            if (productName != null && productPrice != 0 && productCategory != null && productQuantity != 0)
            {
                Product p1 = new Product(productName, productPrice, productCategory, productQuantity);
                return p1;
            }


            return null;
        }
        public static void viewAllProduct()
        {
            Console.WriteLine("Name\t\tPrice\t\tCategory\t\tQuantity");
            foreach (Product viewProduct in ProductCRUD.products)
            {
                Console.WriteLine(viewProduct.productName + "\t\t" + viewProduct.productPrice + "\t\t" + viewProduct.productCategory + "\t\t" + viewProduct.productQuantity);
            }
        }
        public static Product orderedProduct()
        {
            viewAllProduct();
            Console.Clear();
            Console.WriteLine("enter product name:");
            string productName = Console.ReadLine();
            Console.WriteLine("enter product category :");
            string productCategory = Console.ReadLine();
            Console.WriteLine("Enter product  Quantity :");
            int productQuantity = int.Parse(Console.ReadLine());
            if (productName != null && productCategory != null && productQuantity != 0)
            {
                Product p1 = new Product(productName, productCategory, productQuantity);
                return p1;
            }


            return null;


        }

        public static void productTax()
        {
            Console.WriteLine("Enter product price :");
            int productPrice = int.Parse(Console.ReadLine());
            Console.WriteLine("enter product category :");
            string productCategory = Console.ReadLine();
            Product s1 = new Product(productPrice, productCategory);
            float tax1 = s1.calculateTax();
            Console.WriteLine("tax {0} :", tax1);
        }
        public static Product buyProduct()
        {
            //Console.WriteLine("How many products do u want to buy?");
            // int n = int.Parse(Console.ReadLine());
            // for(int x = 0; x<=n ;x++)
            // {
            Console.WriteLine("enter product name:");
            string productName = Console.ReadLine();
            Console.WriteLine("enter product category :");
            string productCategory = Console.ReadLine();
            Console.WriteLine("Enter product  Quantity :");
            int productQuantity = int.Parse(Console.ReadLine());
            if (productName != null && productCategory != null && productQuantity != 0)
            {
                Product p1 = new Product(productName, productCategory, productQuantity);
                return p1;
            }
            // }
            return null;

        }
        public static float genericVoice()
        {
            Console.WriteLine("enter customer name :");
            string orderedProduct = Console.ReadLine();
            Console.WriteLine("enter ordered product :");
            string orderedCategory = Console.ReadLine();
            Customer c1 = new Customer(orderedProduct, orderedCategory);
            Console.Clear();
            Console.WriteLine("Enter product price :");
            int productPrice = int.Parse(Console.ReadLine());
            Console.WriteLine("enter product category :");
            string productCategory = Console.ReadLine();
            Product s1 = new Product(productPrice, productCategory);

            float tax1 = s1.calculateTax();
            Console.WriteLine("tax {0} :", tax1);
            return tax1;
        }


    }
}

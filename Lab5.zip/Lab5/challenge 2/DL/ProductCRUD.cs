﻿using Challenge3.BL;
using Challenge3.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.DL
{
    public class ProductCRUD
    {
        public static List<Product> products = new List<Product>();


        public static void storeInList(Product p1)
        {
            products.Add(p1);
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2.BL
{
    class student
    {
        //public student(string n, float m, float f, float e, float a)
        //{
        //    name = n;
        //    matric = m;
        //    fsc = f;
        //    ecat = e;
        //    aggregate = a;
        //}
        public student()
        {
            Console.WriteLine("Default Constructor");
        }
        public student(student s)
        {
            name = s.name;
            matric = s.matric;
            fsc = s.fsc;
            ecat = s.ecat;
            aggregate = s.aggregate;
        }
        public string name;
        public float matric;
        public float fsc;
        public float ecat;
        public float aggregate;
    }
}

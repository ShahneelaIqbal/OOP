﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.BL
{
    public class Customer
    {
        public string orderedProduct;
        public string orderedCategory;
        public Customer(string orderedProduct, string orderedCategory)
        {
            this.orderedProduct = orderedProduct;
            this.orderedCategory = orderedCategory;
        }
    }
}

﻿using project2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter author name: ");
            string author = Console.ReadLine();
            Console.WriteLine("Enter book's page number: ");
            int page = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter book mark: ");
            int bookMarks = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter book's price: ");
            int price = int.Parse(Console.ReadLine());

            book user = new book(author, page, bookMarks, price);
            int option = menu();

            do
            {

                option = menu();
                if (option == 1)
                {
                    Console.Clear();
                    Console.WriteLine("Enter Chapter Number: ");
                    int chapterNumber = int.Parse(Console.ReadLine());
                    string chapterName = user.getChapter(chapterNumber);
                    Console.WriteLine(chapterName);
                    Console.ReadKey();
                }
                if (option == 2)
                {
                    Console.Clear();
                    int mark = user.getBookMark();
                    Console.WriteLine("BookMark is: {0} page number", mark);
                    Console.ReadKey();
                }
                if (option == 3)
                {
                    Console.Clear();
                    Console.WriteLine("Enter BookMark");
                    int mark = int.Parse(Console.ReadLine());
                    user.setBookMark(mark);
                }
                if (option == 4)
                {
                    Console.Clear();
                    int p = user.priceOfBook();
                    Console.WriteLine("Price of book: {0} ", p);
                    Console.ReadKey();
                }
                if (option == 5)
                {
                    Console.Clear();
                    Console.WriteLine("Enter Book Price: ");
                    int p = int.Parse(Console.ReadLine());
                    user.newPrice(p);
                }
                if (option == 6)
                {
                    break;
                }

            }
            while (option != 6);
            Console.ReadKey();

        }

        static int menu()
        {
            Console.Clear();
            Console.WriteLine("1. Get Chapter");
            Console.WriteLine("2. Get BookMark");
            Console.WriteLine("3. Set BookMark");
            Console.WriteLine("4. Get BookPrice");
            Console.WriteLine("5. Set BookPrice");
            Console.WriteLine("Enter Your Choice...");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
       
        
        
        
    }

}


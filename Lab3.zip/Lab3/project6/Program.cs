﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<product> p = new List<product>();
            List<Customer> list = new List<Customer>();

            int opt;
            opt = menu1();
            if(opt == 1)
            {
                int option;
                do
                {
                    Console.Clear();
                    option = menu();
                    if (option == 1)
                    {
                        p.Add(addData());
                    }
                    else if (option == 2)
                    {
                        viewProduct(p);
                    }
                    else if (option == 3)
                    {
                        highestPrice(p);
                    }
                    else if (option == 4)
                    {
                        viewSalesTax(p);
                    }
                    else if (option == 5)
                    {
                        productsOrdered(p);
                    }
                }
                while (option < 6);
                Console.ReadKey();
            }
            else if(opt == 2)
            {
                int option;
                do
                {

                    option = custMenu();
                    if(option == 1)
                    {
                        viewProduct(p);
                    }

                    if(option == 2)
                    {
                        p.Add(addData());
                        viewProduct(p);
                        int choice;
                        Console.WriteLine("How many things do you want to buy: ");
                        choice = int.Parse(Console.ReadLine());
                        for(int x = 0; x < choice; x ++)
                        {
                            Customer data = buy();
                            storeInList(list, data);
                            foreach(var i in list)
                            {
                                Console.WriteLine($"{i.name}, {i.category}, {i.price}");
                            }
                        }
                    }
                }
                while (option < 4);
                
            }
            
        }
        static int menu()
        {
            Console.Clear();
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. View all Products");
            Console.WriteLine("3. Product With highest Price");
            Console.WriteLine("4. View sales tax of all Product");
            Console.WriteLine("5. Product to be odered(less than threshold)");
            Console.WriteLine("6. Exit");
            Console.WriteLine(" Enter Option: ");
            int op = int.Parse(Console.ReadLine());
            return op;
        }
        static product addData()
        {
            Console.Clear();
            product customer = new product();
            Console.WriteLine("Enter the Product name: ");
            customer.productName = Console.ReadLine();
            Console.WriteLine("Enter the Product Category: ");
            customer.productCategory = Console.ReadLine();
            Console.WriteLine("Enter the Product Price: ");
            customer.productPrice = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Product stock quantity: ");
            customer.productQuantity = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Product minimum stock: ");
            customer.productStock = float.Parse(Console.ReadLine());
            Console.ReadKey();
            return customer;
        }
        static void viewProduct(List<product> p)
        {
            Console.Clear();
            Console.WriteLine("All Products!!  ");
            for (int i = 0; i < p.Count; i++)
            {
                Console.WriteLine(p[i].productName + "\t" + p[i].productCategory + "\t" + p[i].productPrice + "\t" + p[i].productQuantity + "\t" + p[i].productStock);
            }

            Console.ReadKey();
        }
        static int highest(List<product> p)
        {
            int high = 0;
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i + 1].productPrice > p[i].productPrice)
                {
                    high = i + 1;
                }
            }
            return high;
        }
        static void highestPrice(List<product> p)
        {
            int idx = highest(p);
            Console.WriteLine(p[idx].productName + "\t" + p[idx].productPrice + "\t" + p[idx].productCategory);
            Console.ReadKey();
        }
        static void viewSalesTax(List<product> p)
        {
            Console.Clear();
            Console.WriteLine("Sales Tax....");
            float tax = 0;
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].productCategory == "Grocery" || p[i].productCategory == "grocery")
                {
                    tax = (float)(p[i].productPrice * 0.1);
                    Console.WriteLine("{0}\t{1}", p[i].productName, tax);
                }
                else if (p[i].productCategory == "Fruit" || p[i].productCategory == "fruit")
                {
                    tax = (float)(p[i].productPrice * 0.05);
                    Console.WriteLine("{0}\t{1}", p[i].productName, tax);
                }
                else
                {
                    tax = (float)(p[i].productPrice * 0.15);
                    Console.WriteLine("{0}\t{1}", p[i].productName, tax);
                }
            }
            Console.ReadKey();
        }
        static void productsOrdered(List<product> p)
        {
            Console.Clear();
            Console.WriteLine("Products To be Ordeded.....");
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].productQuantity < p[i].productStock)
                {
                    Console.WriteLine(p[i].productName);
                }
            }
            Console.ReadKey();


        }

        static int menu1()
        {
            Console.Clear();
            int opt;
            Console.WriteLine("1.Product");
            Console.WriteLine("2.Customer");
            Console.WriteLine("Enter option: ");
            opt = int.Parse(Console.ReadLine());
            return opt;
        }

        static int custMenu()
        {
            Console.Clear();
            Console.WriteLine("1.View all product");
            Console.WriteLine("2.Buy product");
            Console.WriteLine("3.Generate invoice");
            Console.WriteLine("4. Exit");
            Console.WriteLine("Enter option: ");
            int opt = int.Parse(Console.ReadLine());
            return opt;
        }

        static Customer buy()
        {
            Console.WriteLine("Enter the Product name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter category: ");
            string category = Console.ReadLine();
            Console.WriteLine("Enter Price: ");
            float price = float.Parse(Console.ReadLine());

            Customer p = new Customer(name, category, price);
            return p;

        }

        static void storeInList(List<Customer> list, Customer p)
        {
            list.Add(p);
        }

    }
}

﻿
namespace Sign
{
    partial class SignInAndSignUpApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSignInUp = new System.Windows.Forms.Label();
            this.SignIn = new System.Windows.Forms.CheckBox();
            this.SignUp = new System.Windows.Forms.CheckBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSignInUp
            // 
            this.lblSignInUp.AutoSize = true;
            this.lblSignInUp.Font = new System.Drawing.Font("Snap ITC", 14.14286F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSignInUp.Location = new System.Drawing.Point(106, 45);
            this.lblSignInUp.Name = "lblSignInUp";
            this.lblSignInUp.Size = new System.Drawing.Size(560, 44);
            this.lblSignInUp.TabIndex = 0;
            this.lblSignInUp.Text = "SignIn SignUP Application";
            this.lblSignInUp.Click += new System.EventHandler(this.lblSignInUp_Click);
            // 
            // SignIn
            // 
            this.SignIn.AutoSize = true;
            this.SignIn.Location = new System.Drawing.Point(114, 270);
            this.SignIn.Name = "SignIn";
            this.SignIn.Size = new System.Drawing.Size(99, 29);
            this.SignIn.TabIndex = 1;
            this.SignIn.Text = "Sign In";
            this.SignIn.UseVisualStyleBackColor = true;
            // 
            // SignUp
            // 
            this.SignUp.AutoSize = true;
            this.SignUp.Location = new System.Drawing.Point(558, 270);
            this.SignUp.Name = "SignUp";
            this.SignUp.Size = new System.Drawing.Size(108, 29);
            this.SignUp.TabIndex = 2;
            this.SignUp.Text = "Sign Up";
            this.SignUp.UseVisualStyleBackColor = true;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(612, 342);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(125, 59);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // SignInAndSignUpApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 522);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.SignUp);
            this.Controls.Add(this.SignIn);
            this.Controls.Add(this.lblSignInUp);
            this.Name = "SignInAndSignUpApplication";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.SignInAndSignUpApplication_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSignInUp;
        private System.Windows.Forms.CheckBox SignIn;
        private System.Windows.Forms.CheckBox SignUp;
        private System.Windows.Forms.Button btnNext;
    }
}


﻿using project5.clock;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class Program
    {
        static void Main(string[] args)
        {
            clockType elapsed_time = new clockType(8,10,10);
            int result = elapsed_time.elapsed();
            int remaining = elapsed_time.remain(result);
            Console.WriteLine("Elapsed Time: " + result);
            Console.WriteLine("Remaining Time: " + remaining);
            elapsed_time.difference(20, 30, 17);
            Console.Read();
        }
    }
}

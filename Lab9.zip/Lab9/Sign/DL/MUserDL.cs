﻿using Sign.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sign.DL
{
    class MUserDL
    {
        private static List<MUser> usersList = new List<MUser>();

        public static void addUserIntoList(MUser user)
        {
            usersList.Add(user);
        }
        public static MUser SignIn(MUser user)
        {
            foreach (MUser storeUser in usersList)
            {
                if (storeUser.getUserName() == user.getUserName() && storeUser.getUserPassword() == user.getUserPassword())
                {
                    return storeUser;
                }

            }
            return null;
        }
        

        public static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }

        public static bool readData(string path)
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string userName = parseData(record, 1);
                    string userPassword = parseData(record, 2);
                    string userRole = parseData(record, 3);
                    MUser user = new MUser(userName, userPassword, userPassword);
                    addUserIntoList(user);
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }

        public static void storeDataInFile(MUser user, string path)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.getUserName() + "," + user.getUserPassword() + "," + user.getUserPassword());
            file.Flush();
            file.Close();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2
{
    class Program
    {
        static void Main(string[] args)
        {
            shop[] p = new shop[20];
            char option;
            int count = 0;
            do
            {
                option = menu();
                if (option == '1')
                {
                    p[count] = addProduct();
                    count = count + 1;
                }
                else if (option == '2')
                {
                    viewProduct(p, count);
                }
                else if (option == '3')
                {
                    worth(p, count);
                }
                else if (option == '4')
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Choice");
                }
            }
            while (option != '4');
            Console.WriteLine("Press enter to exit..");
            Console.ReadLine();
                       
        }
    
        static char menu()
        {
            Console.Clear();
            char choice;
            Console.WriteLine("Press 1 for adding product");
            Console.WriteLine("Press 2 for view product");
            Console.WriteLine("Press 3 for total worth");
            Console.WriteLine("Press 4 to exit");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static shop addProduct()
        {
            Console.Clear();
            shop s1 = new shop();
            Console.WriteLine("Enter product id:");
            s1.id = Console.ReadLine();
            Console.WriteLine("Enter product name:");
            s1.name = Console.ReadLine();
            Console.WriteLine("Enter product price:");
            s1.price = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter product category:");
            s1.category = Console.ReadLine();
            Console.WriteLine("Enter brand name:");
            s1.brandName = Console.ReadLine();
            Console.WriteLine("Enter product's country:");
            s1.country = Console.ReadLine();
            return s1;
        }
        static void viewProduct(shop[] p, int count)
        {
            Console.Clear();
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("ID: {0} Name: {1} Price: {2} Category: {3} Brand Name: {4} Country: {5}", p[i].id, p[i].name, p[i].price, p[i].category, p[i].brandName, p[i].country);
            }
            Console.WriteLine("Press any key to continue..");
            Console.ReadKey();
        }
        static void worth(shop[] p, int count)
        {
            Console.Clear();
            float add = 0;
            for (int i = 0; i < count; i++)
            {
                add = add + p[i].price;
            }
            Console.WriteLine("Total worth is {0}", add);
            Console.WriteLine("Press any key to continue..");
            Console.ReadKey();
        }
    }
}

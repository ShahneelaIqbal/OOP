﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.BL
{
     public class GameCell
     {
        public int X;
        public int Y;
        public GameObject currentGameObject;
        public GameGrid gameGrid;

        public GameCell(int x, int y, GameGrid gameGrid)
        {
            this.X = x;
            this.Y = y;
            this.gameGrid = gameGrid;
        }
        //public void nextCell(GameDirection direction)
        //{
        //    if (direction == GameDirection.UP)
        //    {

        //    }
        //}
     }
}

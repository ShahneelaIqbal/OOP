﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project6
{
    class product
    {
        public product()
        {

        }
        public product(string n, string c, float p, float q, float s)
        {
            productName = n;
            productCategory = c;
            productPrice = p;
            productQuantity = q;
            productStock = s;
        }

        

        public string productName;
        public string productCategory;
        public float productPrice;
        public float productQuantity;
        public float productStock;
    }
}

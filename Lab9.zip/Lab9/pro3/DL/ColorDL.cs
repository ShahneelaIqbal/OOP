﻿using pro3.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro3.DL
{
     class ColorDL
     {
        public static List<Color> name = new List<Color>();

        Color red = new Color("red");
        Color green = new Color("green");
        Color blue = new Color("blue");

     }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project3
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = "D:\\Semester 2\\OOP\\Labs\\Lab2\\student.txt";
            credentials[] c = new credentials[20];
            int option;
            int count = 0;
            count = readData(path, c);
            do
            {
                
                Console.Clear();
                option = menu();
                Console.Clear();
                if (option == 1)
                {
                    Console.WriteLine("Enter name:");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter password:");
                    string password = Console.ReadLine();
                    signIn(name, password, c, count);
                }
                else if (option == 2)
                {
                    c[count] = total();
                    count++;
                    signUp(c, path, count);
                }
            }
            while (option < 3);
            Console.ReadKey();

        }
        static int menu()
        {
            int option;
            Console.WriteLine("1.  SignIn");
            Console.WriteLine("2.  SignUp");
            Console.WriteLine("Enter option");
            option = int.Parse(Console.ReadLine());
            return option;
        }
        static string parseData(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        static int readData(string path, credentials[] c)
        {
            int x = 0;
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    credentials data = new credentials();
                    data.userName = parseData(record, 1);
                    data.password = parseData(record, 2);
                    c[x++] = data;
                    if (x >= 20)
                    {
                        break;
                    }
                }
                fileVariable.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
            return x;
        }
        static void signIn(string name, string password, credentials[] c, int count)
        {
            bool flag = false;
            for (int x = 0; x < count; x++)
            {
                if (name == c[x].userName && password == c[x].password)
                {
                    Console.WriteLine("Valid User");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                    flag = true;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Invalid User");
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
            }
            Console.ReadKey();
        }
        static void signUp(credentials[] c, string path, int count)
        {
            StreamWriter file = new StreamWriter(path, true);
            for (int i = 0; i < count; i++) 
            {
                file.WriteLine(c[i].userName + "," + c[i].password);
            }
            file.Flush();
            file.Close();
        }
        static credentials total()
        {
            credentials s1 = new credentials();
            Console.WriteLine("Enter name :");
            s1.userName = Console.ReadLine();
            Console.WriteLine("Enter password :");
            s1.password = Console.ReadLine();
            return s1;

        }





    }
}

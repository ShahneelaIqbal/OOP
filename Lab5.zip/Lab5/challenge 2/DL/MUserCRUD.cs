﻿using Challenge3.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge3.DL
{
    public class MUserCRUD
    {
        public static List<MUser> users = new List<MUser>();
        public static MUser SignIn(MUser user)
        {
            foreach (MUser storeUser in users)
            {
                if (user.username == storeUser.username && user.password == storeUser.password)
                {
                    return storeUser;
                }

            }
            return null;
        }
        public static void storeDataInList(MUser user)
        {
            users.Add(user);

        }
    }
}

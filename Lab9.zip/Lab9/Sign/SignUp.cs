﻿using Sign.BL;
using Sign.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sign
{
    public partial class SignUpForm : Form
    {
        public SignUpForm()
        {
            InitializeComponent();
        }

        private void clearDataFromForm()
        {
            txtName.Text = "";
            txtPassword.Text = "";
            txtRole.Text = "";
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string password = txtPassword.Text;
            string role = txtRole.Text;
            string path = "data.txt";
            MUser user = new MUser(username, password, role);
            MUserDL.addUserIntoList(user);
            MUserDL.storeDataInFile(user, path);
            MessageBox.Show("User Added Successfully");
            clearDataFromForm();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

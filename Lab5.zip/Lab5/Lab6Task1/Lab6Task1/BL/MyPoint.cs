﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6Task1.BL
{
    public class MyPoint
    {
        public MyPoint()
        {

        }
        public MyPoint(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        public int x;
        public int y;
        internal object begin;

        public int getX()
        {
            return x;
        }
        public int getY()
        {
            return y;
        }
        public void setX(int x)
        {
            this.x = x;
        }
        public void setY(int y)
        {
            this.y = y;
        }
        public void setXY(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        public double distanceWithCords(int x,int y)
        {
            double dis = (((this.x - x) * (this.x - x)) + ((this.y - y)*(this.y - y)));
            dis = Math.Sqrt(dis);
            return dis;
        }
        public double distanceWithObject(MyPoint another)
        {
            double dis = (Math.Pow( this.x - another.x,2) + ((this.y - another.y) * (this.y - another.y)));
            dis = Math.Sqrt(dis);
            return dis;
        }
        public double distanceFromZero()
        {
            double dis = Math.Sqrt(((x * x) + (y * y)));
            return dis;
        }     



    }
}

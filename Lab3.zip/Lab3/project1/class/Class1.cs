﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1
{
    class student
    {
        public student()
        {
            //Console.WriteLine("Default Constructor Called");
            name = "Ethan";
            matric = 1009;
            fsc = 1050.6F;
            ecat = 200;
            aggregate = 80.9F;
        }
        public string name;
        public float matric;
        public float fsc;
        public float ecat;
        public float aggregate;
    }
}

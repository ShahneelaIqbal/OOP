﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1task4
{
    class Program
    {
        static void Main(string[] args)
        {
            int orders;
            int orderPrice;
            string path = "D:\\Semester 2\\OOP\\Lab1\\Customer.txt";
            Console.Write("Enter number of order:");
            orders = int.Parse(Console.ReadLine());
            Console.Write("Enter order price:");
            orderPrice = int.Parse(Console.ReadLine());
            read(orders, orderPrice, path);
            Console.ReadKey();
        }
        static void read(int orders, int orderPrice, string path)
        {
            string name;
            int order1;
            string order;
            int count = 0;
            string price;
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    name = parseData(record, 1);
                    order = parseData(record, 2);
                    order1 = int.Parse(order);
                    if (order1 >= orders)
                    {
                        price = parseData(record, 3);
                        for (int idx = 1; idx <= order1; idx++)
                        {
                            int noOfPrice = parseRecord(price, idx);
                            if (noOfPrice >= orderPrice)
                            {
                                count = count + 1;
                            }
                        }
                        if (count >= order1)
                        {
                            Console.WriteLine("Name is {0} ", name);
                        }
                        else if(count < order1)
                        {
                            Console.WriteLine("No one get pizza");
                        }
                    }
                }
            }
        }
        static string parseData(string record, int field)
        {
            string item1 = "";
            int comma = 1;
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ' ')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item1 = item1 + record[x];
                }
            }
            return item1;

        }
        static int parseRecord(string price, int field)
        {
            string item = "";
            int comma = 1;
            int price1;
            for (int x = 0; x < price.Length; x++)
            {
                if (price[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + price[x];
                }
            }
            price1 = int.Parse(item);
            return price1;
        }
    }
}

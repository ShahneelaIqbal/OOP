﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sign.BL
{
    public class MUser
    {
        private string userName;
        private string userPassword;
        private string userRole;

        public MUser(string username, string password, string role)
        {
            this.userName = username;
            this.userPassword = password;
            this.userRole = role;

        }
        public MUser(string username, string password)
        {
            this.userName = username;
            this.userPassword = password;

        }

        public string getUserName()
        {
            return userName;
        }

        public string getUserPassword()
        {
            return userPassword;
        }

        public string getUserRole()
        {
            return userRole;
        }

        public bool isAdmin()
        {
            if (userRole == "admin" || userRole == "Admin")
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }
    }
}

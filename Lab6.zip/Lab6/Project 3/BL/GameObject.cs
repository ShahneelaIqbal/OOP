﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3.BL
{
    class GameObject
    {
        public char[,] shape;
        public Point StartingPoint;
        public Boundary Premise;
        public string Direction;
        private int parabolicCount;
        private Point leftboundary;
        private Point rightBoundary;

        public GameObject()
        {
            shape = new char[1, 3] { { '*', '*', '*' } };
            StartingPoint.setXY(0, 0);
            Premise.BottomLeft.setXY(90, 0);
            Premise.BottomRight.setXY(90, 90);
            Premise.TopLeft.setXY(90, 0);
            Premise.TopRight.setXY(0, 90);
            parabolicCount = 0;

        }

        public GameObject(char[,] shape, Point startingPoint, Boundary Premise, string Direction)
        {
            this.shape = shape;
            this.StartingPoint = startingPoint;
            this.Premise = Premise;
            this.Direction = Direction;
            parabolicCount = 0;
        }

        public void move()
        {
            if (IsPatrolling())
            {
                Patrol();
            }
            else if (Direction.ToLower() == "lefttoright")
            {
                MoveRight();
            }
            else if (Direction.ToLower() == "righttoleft")
            {
                MoveLeft();
            }
            else if (Direction.ToLower() == "diagonal")
            {
                MoveDiagonalDown();
            }
            else if (Direction.ToLower() == "parabola")
            {
                Parabola();
            }
        }

        private bool IsPatrolling()
        {

            return (Direction.ToLower() == "patrolleft") || (Direction == "patrolright");
        }

        private void Parabola()
        {
            if (parabolicCount < 4)
            {
                MoveDiagonalUp();
            }
            else if (parabolicCount < 6)
            {
                MoveRight();
            }
            else if (parabolicCount < 10)
            {
                MoveDiagonalDown();
            }
            parabolicCount++;
        }

        private void Patrol()
        {

            if (IsAtRightEdge() || IsAtLeftEdge())
            {
                ChangePatrolDirection();
            }

            MoveHorizontally();
        }

        private bool IsAtRightEdge()
        {
            return StartingPoint.getX() + 3 == Premise.TopRight.getX() || StartingPoint.getX() + 3 == Premise.BottomRight.getX();
        }

        private bool IsAtLeftEdge()
        {
            return StartingPoint.getX() == Premise.TopLeft.getX() || StartingPoint.getX() == Premise.BottomLeft.getX();
        }

        private void ChangePatrolDirection()
        {
            if (Direction.ToLower() == "patrolleft")
            {
                Direction = "patrolright";
            }
            else if (Direction.ToLower() == "patrolright")
            {
                Direction = "patrolleft";
            }
        }
        private void MoveHorizontally()
        {
            if (Direction.ToLower() == "patrolleft")
            {
                StartingPoint.setX(StartingPoint.getX() - 1);
            }
            else if (Direction.ToLower() == "patrolright")
            {
                StartingPoint.setX(StartingPoint.getX() + 1);
            }
        }
        private void MoveRight()
        {
            if (StartingPoint.getX() + 3 < Premise.TopRight.getX() && StartingPoint.getX() + 3 < Premise.BottomRight.getX())
            {
                StartingPoint.setX(StartingPoint.getX() + 1);
            }
        }
        private void MoveLeft()
        {
            if (StartingPoint.getX() > Premise.TopLeft.getX() && StartingPoint.getX() > Premise.BottomLeft.getX())
            {
                StartingPoint.setX(StartingPoint.getX() - 1);
            }
        }
        private void MoveDiagonalDown()
        {
            if (StartingPoint.getY() < Premise.BottomRight.getY())
            {
                StartingPoint.setY(StartingPoint.getY() + 1);
            }
            if (StartingPoint.getX() + 3 < Premise.BottomRight.getX())
            {
                StartingPoint.setX(StartingPoint.getX() + 1);
            }
        }
        private void MoveDiagonalUp()
        {
            if (StartingPoint.getY() > Premise.TopRight.getY())
            {
                StartingPoint.setY(StartingPoint.getY() - 1);
            }
            if (StartingPoint.getX() + 3 < Premise.TopRight.getX())
            {
                StartingPoint.setX(StartingPoint.getX() + 1);
            }
        }
        public void draw()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.SetCursorPosition(this.StartingPoint.x, this.StartingPoint.y + i);
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(shape[i, j]);
                }
                Console.WriteLine();
            }
        }
        public void erase()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.SetCursorPosition(this.StartingPoint.x, this.StartingPoint.y + i);
                for (int j = 0; j < 5; j++)
                {
                    Console.Write(' ');
                }
                Console.WriteLine();
            }
        }

    }
}
